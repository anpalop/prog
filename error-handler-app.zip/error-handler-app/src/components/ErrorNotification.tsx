import React from 'react';
import { useError, ApiError } from '../contexts/ErrorContext';
import './ErrorNotification.css';

const ErrorNotification: React.FC = () => {
  const { errors, removeError, clearErrors } = useError();

  if (errors.length === 0) return null;

  return (
    <div className="error-container">
      <div className="error-header">
        <h3>🚨 Errores de API</h3>
        <button 
          className="clear-all-btn"
          onClick={clearErrors}
          title="Limpiar todos los errores"
        >
          ✕ Limpiar todo
        </button>
      </div>
      
      <div className="error-list">
        {errors.map((error, index) => (
          <div key={index} className="error-item">
            <div className="error-content">
              <div className="error-message">
                <strong>Error:</strong> {error.message}
              </div>
              
              {error.status && (
                <div className="error-details">
                  <span className="error-status">Status: {error.status}</span>
                </div>
              )}
              
              {error.code && (
                <div className="error-details">
                  <span className="error-code">Código: {error.code}</span>
                </div>
              )}
              
              <div className="error-timestamp">
                {error.timestamp.toLocaleTimeString()}
              </div>
            </div>
            
            <button 
              className="remove-error-btn"
              onClick={() => removeError(index)}
              title="Cerrar error"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ErrorNotification;
