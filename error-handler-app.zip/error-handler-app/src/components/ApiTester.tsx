import React, { useState } from 'react';
import { useApi } from '../hooks/useApi';
import { useError } from '../contexts/ErrorContext';
import './ApiTester.css';

const ApiTester: React.FC = () => {
  const { data, loading, simulateApiCall } = useApi();
  const { errors, clearErrors } = useError();
  const [selectedEndpoint, setSelectedEndpoint] = useState('users');

  const endpoints = [
    { value: 'users', label: '👥 Usuarios' },
    { value: 'products', label: '📦 Productos' },
    { value: 'orders', label: '📋 Pedidos' },
    { value: 'auth', label: '🔐 Autenticación' },
    { value: 'payments', label: '💳 Pagos' }
  ];

  const handleSuccessCall = async () => {
    try {
      await simulateApiCall(selectedEndpoint, false);
    } catch (error) {
      // El error ya se maneja en el hook
    }
  };

  const handleErrorCall = async () => {
    try {
      await simulateApiCall(selectedEndpoint, true);
    } catch (error) {
      // El error ya se maneja en el hook
    }
  };

  const handleMultipleErrors = async () => {
    // Generar múltiples errores rápidamente
    for (let i = 0; i < 3; i++) {
      setTimeout(() => {
        simulateApiCall(`endpoint-${i}`, true);
      }, i * 500);
    }
  };

  return (
    <div className="api-tester">
      <div className="tester-header">
        <h2>🧪 Probador de API</h2>
        <p>Simula llamadas exitosas y con errores a diferentes endpoints</p>
      </div>

      <div className="tester-controls">
        <div className="endpoint-selector">
          <label htmlFor="endpoint">Selecciona un endpoint:</label>
          <select
            id="endpoint"
            value={selectedEndpoint}
            onChange={(e) => setSelectedEndpoint(e.target.value)}
            className="endpoint-select"
          >
            {endpoints.map(endpoint => (
              <option key={endpoint.value} value={endpoint.value}>
                {endpoint.label}
              </option>
            ))}
          </select>
        </div>

        <div className="button-group">
          <button
            className="btn btn-success"
            onClick={handleSuccessCall}
            disabled={loading}
          >
            {loading ? '⏳ Cargando...' : '✅ Llamada Exitosa'}
          </button>

          <button
            className="btn btn-danger"
            onClick={handleErrorCall}
            disabled={loading}
          >
            {loading ? '⏳ Cargando...' : '❌ Llamada con Error'}
          </button>

          <button
            className="btn btn-warning"
            onClick={handleMultipleErrors}
            disabled={loading}
          >
            🚨 Múltiples Errores
          </button>
        </div>
      </div>

      {data && (
        <div className="success-response">
          <h3>✅ Respuesta Exitosa</h3>
          <div className="response-content">
            <pre>{JSON.stringify(data, null, 2)}</pre>
          </div>
        </div>
      )}

      <div className="error-stats">
        <div className="stats-card">
          <div className="stats-number">{errors.length}</div>
          <div className="stats-label">Errores Activos</div>
        </div>
        
        <div className="stats-card">
          <div className="stats-number">
            {errors.filter(e => e.status && e.status >= 500).length}
          </div>
          <div className="stats-label">Errores del Servidor</div>
        </div>
        
        <div className="stats-card">
          <div className="stats-number">
            {errors.filter(e => e.status && e.status >= 400 && e.status < 500).length}
          </div>
          <div className="stats-label">Errores del Cliente</div>
        </div>

        {errors.length > 0 && (
          <button
            className="btn btn-secondary clear-btn"
            onClick={clearErrors}
          >
            🧹 Limpiar Todos los Errores
          </button>
        )}
      </div>

      <div className="features-info">
        <h3>🎯 Características del Manejador de Errores</h3>
        <ul>
          <li>✅ Captura automática de errores de API</li>
          <li>✅ Notificaciones en tiempo real</li>
          <li>✅ Auto-eliminación después de 5 segundos</li>
          <li>✅ Diferentes tipos de errores (404, 500, 401, etc.)</li>
          <li>✅ Información detallada (status, código, timestamp)</li>
          <li>✅ Interfaz responsive y moderna</li>
        </ul>
      </div>
    </div>
  );
};

export default ApiTester;
