import { useState } from 'react';
import { useError } from '../contexts/ErrorContext';

// Tipos para las respuestas de la API
interface ApiResponse<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

// Hook personalizado para manejar llamadas a la API
export const useApi = <T = any>() => {
  const [state, setState] = useState<ApiResponse<T>>({
    data: null,
    loading: false,
    error: null
  });
  
  const { addError } = useError();

  // Función para hacer llamadas a la API
  const callApi = async (apiCall: () => Promise<T>) => {
    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const data = await apiCall();
      setState({ data, loading: false, error: null });
      return data;
    } catch (error: any) {
      const errorMessage = error.message || 'Error desconocido';
      const status = error.response?.status;
      const code = error.code;
      
      // Agregar error al contexto global
      addError({
        message: errorMessage,
        status,
        code,
        details: error.response?.data
      });

      setState({ 
        data: null, 
        loading: false, 
        error: errorMessage 
      });
      
      throw error;
    }
  };

  // Función para simular llamadas a diferentes endpoints
  const simulateApiCall = async (endpoint: string, shouldFail: boolean = false) => {
    return callApi(async () => {
      // Simular delay de red
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (shouldFail) {
        // Simular diferentes tipos de errores
        const errorTypes = [
          { message: 'Error 404: Recurso no encontrado', status: 404, code: 'NOT_FOUND' },
          { message: 'Error 500: Error interno del servidor', status: 500, code: 'INTERNAL_ERROR' },
          { message: 'Error 401: No autorizado', status: 401, code: 'UNAUTHORIZED' },
          { message: 'Error 400: Solicitud inválida', status: 400, code: 'BAD_REQUEST' },
          { message: 'Error de conexión: No se pudo conectar al servidor', code: 'CONNECTION_ERROR' }
        ];
        
        const randomError = errorTypes[Math.floor(Math.random() * errorTypes.length)];
        const error = new Error(randomError.message);
        (error as any).response = { status: randomError.status, data: { code: randomError.code } };
        (error as any).code = randomError.code;
        throw error;
      }
      
      // Simular respuesta exitosa
      return {
        endpoint,
        message: 'Llamada exitosa',
        timestamp: new Date().toISOString(),
        data: { id: Math.random(), name: `Datos de ${endpoint}` }
      } as T;
    });
  };

  return {
    ...state,
    callApi,
    simulateApiCall
  };
};
