import React from 'react';
import { ErrorProvider } from './contexts/ErrorContext';
import ErrorNotification from './components/ErrorNotification';
import ApiTester from './components/ApiTester';
import './App.css';

const App: React.FC = () => {
  return (
    <ErrorProvider>
      <div className="app">
        <header className="app-header">
          <h1>🚨 Manejador de Errores Global</h1>
          <p>Demostración de captura y manejo de errores de API de Node.js</p>
        </header>

        <main className="app-main">
          <ApiTester />
        </main>

        <ErrorNotification />
      </div>
    </ErrorProvider>
  );
};

export default App;
