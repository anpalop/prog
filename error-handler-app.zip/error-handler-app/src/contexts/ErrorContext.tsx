import React, { createContext, useContext, useState, ReactNode } from 'react';

// Tipos para los errores
export interface ApiError {
  message: string;
  status?: number;
  code?: string;
  details?: any;
  timestamp: Date;
}

interface ErrorContextType {
  errors: ApiError[];
  addError: (error: Omit<ApiError, 'timestamp'>) => void;
  removeError: (index: number) => void;
  clearErrors: () => void;
  hasErrors: boolean;
}

const ErrorContext = createContext<ErrorContextType | undefined>(undefined);

// Hook para usar el contexto de errores
export const useError = () => {
  const context = useContext(ErrorContext);
  if (!context) {
    throw new Error('useError debe ser usado dentro de ErrorProvider');
  }
  return context;
};

// Provider del contexto de errores
interface ErrorProviderProps {
  children: ReactNode;
}

export const ErrorProvider: React.FC<ErrorProviderProps> = ({ children }) => {
  const [errors, setErrors] = useState<ApiError[]>([]);

  const addError = (error: Omit<ApiError, 'timestamp'>) => {
    const newError: ApiError = {
      ...error,
      timestamp: new Date()
    };
    
    setErrors(prev => [...prev, newError]);
    
    // Auto-remover errores después de 5 segundos
    setTimeout(() => {
      setErrors(prev => prev.filter((_, index) => index !== prev.length - 1));
    }, 5000);
  };

  const removeError = (index: number) => {
    setErrors(prev => prev.filter((_, i) => i !== index));
  };

  const clearErrors = () => {
    setErrors([]);
  };

  const hasErrors = errors.length > 0;

  return (
    <ErrorContext.Provider value={{
      errors,
      addError,
      removeError,
      clearErrors,
      hasErrors
    }}>
      {children}
    </ErrorContext.Provider>
  );
};
